"""Conservative supply evidence from blind pin attributes and voltage labels.

Names identify nets, never particular projects. Inferred intent has provenance,
does not invent current ratings, and never mutates the caller's specification.
"""
from __future__ import annotations

import copy
import re

GROUND_NAMES = frozenset({'GND', 'AGND', 'DGND', 'PGND', 'VSS'})
_VOLTAGE = re.compile(r'^([+-]?)(\d+)(?:V(\d+)|(\.\d+)?V)(?:$|_)', re.I)
_SUPPLY_PIN = re.compile(r'^(?:(?:A|D|P|U\d*)?VDD|VCC|VBAT|VBUS|VIN|VS|VM)(?:\d|_|$)', re.I)


def voltage_label(name):
    """Recognize lexical voltage labels, including hierarchy and rail suffixes."""
    leaf = str(name).rsplit('/', 1)[-1]
    match = _VOLTAGE.match(leaf)
    if not match:
        return None
    sign, whole, fraction, decimal = match.groups()
    value = float(whole + ('.' + fraction if fraction else decimal or ''))
    return -value if sign == '-' else value


def derive_electrical_requirements(spec):
    derived = copy.deepcopy(spec)
    requirements = derived.setdefault('design_requirements', {})
    rails = requirements.setdefault('power_rails', [])
    declared = {r['net'] for r in rails}
    nets = set(spec.get('nets', {}))
    protected = set(requirements.get('high_speed_or_clock_nets', []))
    protected.update(n for pair in requirements.get('differential_pairs', []) for n in (pair['pos_net'], pair['neg_net']))
    evidence = {}
    for net in nets - declared - protected:
        voltage = voltage_label(net)
        if voltage is not None:
            evidence[net] = [dict(kind='voltage_label', nominal_v=voltage)]
    for comp in spec.get('components', []):
        for pad in comp.get('pads', []):
            net = pad.get('net', '')
            function = str(pad.get('pin_function', '')).upper()
            if net not in nets or net in declared or net in protected or pad.get('pin_type') not in ('power_in', 'power_out'):
                continue
            # Ground, thermal, reference and switch-node pins must not silently
            # become supply trunks merely because a symbol calls them power_in.
            if function in GROUND_NAMES or any(word in function for word in ('GND', 'VSS', 'REF', 'BIAS', 'SW', 'LX')):
                continue
            if _SUPPLY_PIN.match(function) or voltage_label(function) is not None:
                evidence.setdefault(net, []).append(dict(kind='typed_supply_pin', refdes=comp['refdes'], pin=str(pad['num']), function=function, pin_type=pad['pin_type']))
    decisions = []
    for net, reasons in sorted(evidence.items()):
        # A labelled ground net wins over contradictory/incorrect symbol data.
        if net.upper() in GROUND_NAMES:
            continue
        voltage = voltage_label(net)
        rail = dict(net=net, nominal_v=voltage, requirements_source='derived from blind electrical evidence', evidence=reasons, current_verified=False)
        rails.append(rail)
        decisions.append(rail)
    return derived, decisions
