# Cloud PCB Studio

Headless Cloud Multi-Agent EDA Workbench & Board-Agnostic Blind PCB Solver:
- **Parts & DFM (`cloud_pcb/parts_dfm`)**: BOM verification, JLC04161H-7628 4-layer stackup, masked impedance calibration, `ngspice` power/ESD/Monte Carlo simulation.
- **Layout & Route (`cloud_pcb/layout_route`)**: Pipeline A (`@tscircuit/core` -> KiCad/Gerbers) & Pipeline B (KiCad + Specctra DSN/SES bake-off: `fastroute v0.1.14` vs `freerouting-cli v2.5.0`).
- **General Blind Solver (`cloud_pcb/general_solver`)**: Board-agnostic placement, decoupling assignment, SMD GND fanout vias, 4-layer GND pours & stitching vias, Gerber/Excellon export, and `compare_reference.py`.
- **Special IP (`cloud_pcb/special_ip`)**: Planar stacked coils (`In1.Cu` / `In2.Cu` constructive flux), chevron CapTouch slider, curved Chaikin routing.
- **Verify Gate (`cloud_pcb/verify_gate`)**: Strict `pygerber` RS-274X parse, `gerbonara` Excellon check, Shapely topological LVS/DRC, headless Chromium visual audit.

## Quick Setup (Linux / Codex Cloud)

```bash
# Always load the shared environment BEFORE running Python or either router.
source scripts/env.sh

# 1. Python venv + dependencies
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt

# 2. Node dependencies (@tscircuit/core, esbuild, etc.)
npm install
npx playwright install chromium

# 3. Ensure ngspice & chromium/playwright are available if running full verify gate
#    (fastroute & freerouting-cli binaries are included in ./bin/)
source scripts/env.sh
python -m pytest -v
```

The generic v3 runner executes all five cases with one frozen codebase and
writes SHA256 manifests, independent layer-aware LVS, Gerbers and offline 3D
assembly previews:

```bash
source scripts/env.sh
python -m scripts.run_blind_v3
# Only AFTER all five complete outputs are frozen and verified:
python -m scripts.run_blind_v3 --unseal
```

Open `artifacts/blind_v3_caseN/assembly.html` directly in a browser; it contains
its own Three.js code and model geometry. Parametric package envelopes and
estimated heights are identified in `assembly_scene.json`; zero envelope
collisions alone does not certify unknown real mechanical dimensions.
See [the research and implementation limits](docs/v3-design-decisions.zh-CN.md).
